/**
 * Key Derivation for Aegis (Baby Jubjub + Ed25519)
 *
 * Dual-curve architecture (Railgun-style):
 * - Baby Jubjub spending key: SNARK-friendly, in-circuit verification via BabyPbk()
 * - Ed25519 viewing key: Standard fast curve, off-chain ECDH only
 *
 * Key Architecture:
 * ```
 * Solana Wallet (Ed25519)
 *         │
 *         │ signs message: "Aegis key derivation v1"
 *         ▼
 *    Signature (64 bytes)
 *         │
 *         ├──► SHA256(sig || "spend") mod BJJ_ORDER ──► Baby Jubjub Spending Key
 *         │
 *         └──► SHA256(sig || "view") ──► Ed25519 Viewing Key
 * ```
 *
 * Stealth Address Flow:
 * ```
 * Sender:
 *   1. ephemeral = random Ed25519 keypair
 *   2. sharedSecret = X25519(ephemeral.priv, viewingPubX25519)
 *   3. stealthScalar = SHA256(sharedSecret || domain) mod BJJ_ORDER
 *   4. stealthPub = spendingPub + stealthScalar × BASE8
 *   5. commitment = Poseidon(stealthPub.x, amount)
 *
 * Recipient (viewing key - can detect):
 *   1. sharedSecret = X25519(viewingPriv, ephemeralPub)
 *   2. Decrypt amount, derive stealthPub, verify commitment
 *
 * Recipient (spending key - can claim):
 *   1. stealthPriv = spendingPriv + stealthScalar
 *   2. Circuit proves: BabyPbk(stealthPriv).x == pub_key_x
 * ```
 */

import { sha256 } from "@noble/hashes/sha2.js";
import { pbkdf2 } from "@noble/hashes/pbkdf2";
import {
  scalarFromBytes,
  bigintToBytes,
  babyJubMul,
  BABYJUB_BASE8,
  babyJubCompress,
  babyJubDecompress,
  type BabyJubPoint,
} from "./crypto";
import {
  ed25519GetPublicKey,
} from "./crypto-ed25519";
import { computeMPKSync, poseidonHashSync } from "./poseidon";
import { BABYJUB_ORDER } from "./crypto-babyjub";
// circomlibjs is lazily imported to avoid pulling ffjavascript WASM into React Native bundles.
// Only eddsaGetPubKey, eddsaGetPrivScalar, and eddsaPoseidonSign need it (web/Node.js only).
type Eddsa = any;

// ========== Types ==========

/**
 * Complete Aegis key hierarchy derived from Solana wallet
 *
 * Uses Baby Jubjub for spending keys and Ed25519 for viewing keys.
 */
export interface AegisKeys {
  /** Solana public key (32 bytes) - user identity */
  solanaPublicKey: Uint8Array;

  /** Baby Jubjub spending private key (scalar) - for stealthPriv and nullifier */
  spendingPrivKey: bigint;

  /** Baby Jubjub spending public key (point) - share publicly */
  spendingPubKey: BabyJubPoint;

  /** Nullifying key (BN254 scalar) - for JoinSplit nullifier computation */
  nullifyingKey: bigint;

  /** Ed25519 viewing private key (32 bytes) - for X25519 ECDH scanning */
  viewingPrivKey: Uint8Array;

  /** Ed25519 viewing public key (32 bytes) - share publicly */
  viewingPubKey: Uint8Array;

  /** Raw EdDSA seed bytes (32 bytes) - for circomlibjs EdDSA-Poseidon signing */
  eddsaSeed: Uint8Array;
}

/**
 * Stealth meta-address for receiving funds
 *
 * Total size: 96 bytes (32 BJJ compressed + 32 Ed25519 + 32 MPK)
 */
export interface StealthMetaAddress {
  /** Baby Jubjub spending public key (32 bytes compressed) */
  spendingPubKey: Uint8Array;

  /** Ed25519 viewing public key (32 bytes) */
  viewingPubKey: Uint8Array;

  /** Master public key (32 bytes, Poseidon hash as BE bytes) */
  mpk: Uint8Array;
}

/**
 * Serialized stealth meta-address for display/sharing
 */
export interface SerializedStealthMetaAddress {
  /** Hex-encoded spending public key */
  spendingPubKey: string;

  /** Hex-encoded viewing public key */
  viewingPubKey: string;

  /** Hex-encoded master public key (Poseidon hash) */
  mpk: string;
}

/**
 * View permission flags for delegated viewing keys
 */
export enum ViewPermissions {
  /** Can scan announcements and see amounts */
  SCAN = 1 << 0,

  /** Can see full transaction history */
  HISTORY = 1 << 1,

  /** Can see incoming transactions only */
  INCOMING_ONLY = 1 << 2,

  /** Full viewing access (scan + history) */
  FULL = SCAN | HISTORY,
}

/**
 * Delegated viewing key for auditors/compliance
 *
 * Uses Ed25519 private key for viewing
 */
export interface DelegatedViewKey {
  /** Ed25519 viewing private key (32 bytes) */
  viewingPrivKey: Uint8Array;

  /** Permission flags */
  permissions: ViewPermissions;

  /** Optional expiration timestamp (Unix ms) */
  expiresAt?: number;

  /** Optional label for identification */
  label?: string;
}

// ========== Constants ==========

/** Message to sign for key derivation */
export const SPENDING_KEY_DERIVATION_MESSAGE =
  "Aegis key derivation v1";

/** Domain separator for spending key derivation */
const SPENDING_KEY_DOMAIN = "spend";

/** Domain separator for viewing key derivation */
const VIEWING_KEY_DOMAIN = "view";

/** Domain separator for nullifying key derivation */
const NULLIFYING_KEY_DOMAIN = "nullify";

// ========== EdDSA-Poseidon Helpers ==========

let eddsaInstance: Eddsa | null = null;

async function getEddsa(): Promise<Eddsa> {
  if (!eddsaInstance) {
    const { buildEddsa } = await import("circomlibjs");
    eddsaInstance = await buildEddsa();
  }
  return eddsaInstance;
}

/**
 * Derive Baby Jubjub public key from raw seed using circomlibjs EdDSA.
 *
 * circomlibjs internally hashes the seed (like standard EdDSA key derivation),
 * producing keys compatible with the EdDSAPoseidonVerifier circuit.
 * This is NOT the same as `babyJubMul(scalarFromBytes(seed), BASE8)`.
 */
export async function eddsaGetPubKey(seed: Uint8Array): Promise<BabyJubPoint> {
  const eddsa = await getEddsa();
  const F = eddsa.babyJub.F;
  const pubKey = eddsa.prv2pub(new Uint8Array(seed));
  return {
    x: F.toObject(pubKey[0]) as bigint,
    y: F.toObject(pubKey[1]) as bigint,
  };
}

/**
 * Extract the internal EdDSA private scalar from a seed.
 *
 * circomlibjs does: BLAKE-512(seed) → pruneBuffer → fromRprLE(32 bytes) → shr(3)
 * This scalar × BASE8 = the public key from `eddsaGetPubKey(seed)`.
 *
 * We intercept circomlibjs's `pruneBuffer` call during `prv2pub` to capture
 * the intermediate buffer, then replicate the LE→bigint→shr(3) conversion.
 * This avoids directly importing ffjavascript/blake-hash which aren't bundled by webpack.
 */
export async function eddsaGetPrivScalar(seed: Uint8Array): Promise<bigint> {
  const eddsa = await getEddsa();
  const F = eddsa.babyJub.F;

  // Intercept the pruneBuffer call to capture the raw scalar.
  // circomlibjs prv2pub does: sBuff = pruneBuffer(blake512(seed)); s = fromRprLE(sBuff); A = Base8 * (s >> 3)
  // We temporarily replace pruneBuffer to capture sBuff.
  let capturedBuff: Uint8Array | null = null;
  const origPrune = eddsa.pruneBuffer.bind(eddsa);
  (eddsa as any).pruneBuffer = (buff: any) => {
    const result = origPrune(buff);
    capturedBuff = new Uint8Array(result);
    return result;
  };

  try {
    // Call prv2pub which triggers pruneBuffer internally
    eddsa.prv2pub(new Uint8Array(seed));
  } finally {
    // Restore original
    (eddsa as any).pruneBuffer = origPrune;
  }

  if (!capturedBuff) {
    throw new Error("Failed to capture EdDSA scalar buffer");
  }

  // Convert first 32 bytes from little-endian to bigint (same as Scalar.fromRprLE)
  let s = 0n;
  for (let i = 31; i >= 0; i--) {
    s = (s << 8n) | BigInt(capturedBuff[i]);
  }

  // Right-shift by 3 (same as Scalar.shr(s, 3) in circomlibjs)
  return s >> 3n;
}

/**
 * Sign a message hash with EdDSA-Poseidon (circomlibjs).
 *
 * Returns [R8.x, R8.y, S] compatible with the EdDSAPoseidonVerifier circuit.
 */
export async function eddsaPoseidonSign(
  seed: Uint8Array,
  msgHash: bigint,
): Promise<[bigint, bigint, bigint]> {
  const eddsa = await getEddsa();
  const F = eddsa.babyJub.F;
  const msgF = F.e(msgHash);
  const signature = eddsa.signPoseidon(new Uint8Array(seed), msgF);
  const R8x = F.toObject(signature.R8[0]) as bigint;
  const R8y = F.toObject(signature.R8[1]) as bigint;
  const S = signature.S;
  return [R8x, R8y, S];
}

/**
 * Sign a message hash with EdDSA-Poseidon using a given private scalar directly.
 *
 * Unlike `eddsaPoseidonSign` which derives the scalar internally via circomlibjs's
 * BLAKE-512 derivation, this function uses the provided scalar as-is.
 * This is needed when the public key was derived via `scalarFromBytes` (sync)
 * rather than circomlibjs's internal derivation.
 *
 * Returns [R8.x, R8.y, S] compatible with the EdDSAPoseidonVerifier circuit.
 */
export function eddsaPoseidonSignWithScalar(
  privScalar: bigint,
  pubKey: BabyJubPoint,
  msgHash: bigint,
): [bigint, bigint, bigint] {
  // Deterministic nonce: r = Poseidon(privScalar, msgHash) mod BABYJUB_ORDER
  const r = poseidonHashSync([privScalar, msgHash]) % BABYJUB_ORDER;

  // R8 = r * BASE8
  const R8 = babyJubMul(r, BABYJUB_BASE8);

  // hm = Poseidon(R8.x, R8.y, pubKey.x, pubKey.y, msgHash)
  const hm = poseidonHashSync([R8.x, R8.y, pubKey.x, pubKey.y, msgHash]);

  // S = (r + privScalar * hm) mod BABYJUB_ORDER
  const S = (r + privScalar * hm) % BABYJUB_ORDER;

  return [R8.x, R8.y, S];
}

// ========== Wallet Adapter Interface ==========

/**
 * Minimal wallet adapter interface for signing
 * Compatible with @solana/wallet-adapter-base
 */
export interface WalletSignerAdapter {
  publicKey: { toBytes(): Uint8Array } | null;
  signMessage(message: Uint8Array): Promise<Uint8Array>;
}

// ========== Key Derivation ==========

/**
 * Derive Aegis keys from Solana wallet signature.
 *
 * Uses circomlibjs EdDSA for spendingPubKey derivation so keys are
 * compatible with the EdDSAPoseidonVerifier circuit.
 */
export async function deriveKeysFromWallet(
  wallet: WalletSignerAdapter
): Promise<AegisKeys> {
  if (!wallet.publicKey) {
    throw new Error("Wallet not connected");
  }

  const message = new TextEncoder().encode(SPENDING_KEY_DERIVATION_MESSAGE);
  const signature = await wallet.signMessage(message);

  // Start with sync key derivation (babyJubMul-based)
  const baseKeys = deriveKeysFromSignature(signature, wallet.publicKey.toBytes());

  // Override spending keys with circomlibjs-derived versions for circuit compatibility.
  // circomlibjs does: blake512(seed) → prune → fromRprLE → shr(3) → mulPointEscalar(Base8, scalar)
  // Both spendingPrivKey and spendingPubKey must correspond so that:
  //   stealthPriv = spendingPrivKey + stealthScalar → babyJubMul(stealthPriv, BASE8) = stealthPub
  const spendingPubKey = await eddsaGetPubKey(baseKeys.eddsaSeed);
  const spendingPrivKey = await eddsaGetPrivScalar(baseKeys.eddsaSeed);

  return {
    ...baseKeys,
    spendingPubKey,
    spendingPrivKey,
  };
}

/**
 * Derive Aegis keys from a signature
 *
 * Spending key: SHA256(sig || "spend") → reduce mod BJJ_ORDER → babyJubMul(scalar, BASE8)
 * Viewing key: SHA256(sig || "view") → Ed25519 private key → ed25519.getPublicKey()
 */
export function deriveKeysFromSignature(
  signature: Uint8Array,
  solanaPublicKey: Uint8Array
): AegisKeys {
  if (signature.length !== 64) {
    throw new Error("Signature must be 64 bytes");
  }

  if (solanaPublicKey.length !== 32) {
    throw new Error("Solana public key must be 32 bytes");
  }

  // Derive spending key: SHA256(signature || "spend") → Baby Jubjub scalar
  const spendingSeed = sha256(
    concatBytes(signature, new TextEncoder().encode(SPENDING_KEY_DOMAIN))
  );
  // Store raw seed for circomlibjs EdDSA signing (used by deriveKeysFromWallet to override pubkey)
  const eddsaSeed = new Uint8Array(spendingSeed);
  const spendingPrivKey = scalarFromBytes(spendingSeed);
  const spendingPubKey = babyJubMul(spendingPrivKey, BABYJUB_BASE8);

  // Clear intermediate seed
  clearKey(spendingSeed);

  // Derive nullifying key: SHA256(signature || "nullify") → BN254 scalar
  const nullifyingSeed = sha256(
    concatBytes(signature, new TextEncoder().encode(NULLIFYING_KEY_DOMAIN))
  );
  const nullifyingKey = scalarFromBytes(nullifyingSeed);
  clearKey(nullifyingSeed);

  // Derive viewing key: SHA256(signature || "view") → Ed25519 private key
  const viewingPrivKey = sha256(
    concatBytes(signature, new TextEncoder().encode(VIEWING_KEY_DOMAIN))
  );
  const viewingPubKey = ed25519GetPublicKey(viewingPrivKey);

  return {
    solanaPublicKey,
    spendingPrivKey,
    spendingPubKey,
    nullifyingKey,
    viewingPrivKey,
    viewingPubKey,
    eddsaSeed,
  };
}

/**
 * Derive keys from a seed phrase (sync — for scanning/non-circuit use)
 */
export function deriveKeysFromSeed(seed: Uint8Array): AegisKeys {
  const fakeSig = new Uint8Array(64);
  const hash1 = sha256(seed);
  const hash2 = sha256(concatBytes(seed, new Uint8Array([1])));
  fakeSig.set(hash1, 0);
  fakeSig.set(hash2, 32);

  return deriveKeysFromSignature(fakeSig, new Uint8Array(32));
}

/**
 * Derive keys from a seed phrase with circomlibjs-compatible spending keys.
 *
 * Must be used when the keys will be used for circuit proofs (EdDSA signing).
 * The sync `deriveKeysFromSeed` uses a different scalar derivation that doesn't
 * match circomlibjs's internal BLAKE-512 derivation used by `eddsaPoseidonSign`.
 */
export async function deriveKeysFromSeedCircuit(seed: Uint8Array): Promise<AegisKeys> {
  const baseKeys = deriveKeysFromSeed(seed);

  // Override spending keys with circomlibjs-derived versions (same as deriveKeysFromWallet)
  const spendingPubKey = await eddsaGetPubKey(baseKeys.eddsaSeed);
  const spendingPrivKey = await eddsaGetPrivScalar(baseKeys.eddsaSeed);

  return {
    ...baseKeys,
    spendingPubKey,
    spendingPrivKey,
  };
}

// ========== Stealth Meta-Address ==========

/**
 * Create a stealth meta-address from Aegis keys
 *
 * Size: 96 bytes (32 BJJ compressed + 32 Ed25519 + 32 MPK)
 */
export function createStealthMetaAddress(keys: AegisKeys): StealthMetaAddress {
  const mpk = computeMPKSync(
    keys.spendingPubKey.x,
    keys.spendingPubKey.y,
    keys.nullifyingKey
  );
  return {
    spendingPubKey: babyJubCompress(keys.spendingPubKey),
    viewingPubKey: new Uint8Array(keys.viewingPubKey),
    mpk: bigintToBytes(mpk),
  };
}

/**
 * Serialize a stealth meta-address for display/sharing
 */
export function serializeStealthMetaAddress(
  meta: StealthMetaAddress
): SerializedStealthMetaAddress {
  return {
    spendingPubKey: bytesToHex(meta.spendingPubKey),
    viewingPubKey: bytesToHex(meta.viewingPubKey),
    mpk: bytesToHex(meta.mpk),
  };
}

/**
 * Deserialize a stealth meta-address from string representation
 */
export function deserializeStealthMetaAddress(
  serialized: SerializedStealthMetaAddress
): StealthMetaAddress {
  return {
    spendingPubKey: hexToBytes(serialized.spendingPubKey),
    viewingPubKey: hexToBytes(serialized.viewingPubKey),
    mpk: hexToBytes(serialized.mpk),
  };
}

/**
 * Parse a stealth meta-address and extract public keys
 *
 * Returns Baby Jubjub spending pubkey and Ed25519 viewing pubkey.
 */
export function parseStealthMetaAddress(meta: StealthMetaAddress): {
  spendingPubKey: BabyJubPoint;
  viewingPubKey: Uint8Array;
} {
  return {
    spendingPubKey: babyJubDecompress(meta.spendingPubKey),
    viewingPubKey: new Uint8Array(meta.viewingPubKey),
  };
}

/**
 * Encode stealth meta-address as a single string with aegis: prefix
 * Format: "aegis:" + hex(spendingPubKey (32) || viewingPubKey (32) || mpk (32))
 */
export function encodeStealthMetaAddress(meta: StealthMetaAddress): string {
  const combined = concatBytes(meta.spendingPubKey, meta.viewingPubKey, meta.mpk);
  return "aegis:" + bytesToHex(combined);
}

/**
 * Decode stealth meta-address from a string (with or without aegis: prefix)
 */
export function decodeStealthMetaAddress(encoded: string): StealthMetaAddress {
  const hex = encoded.startsWith("aegis:") ? encoded.slice(6) : encoded;
  const bytes = hexToBytes(hex);
  if (bytes.length !== 96) {
    throw new Error("Invalid stealth meta-address length (expected 96 bytes)");
  }
  return {
    spendingPubKey: bytes.slice(0, 32),
    viewingPubKey: bytes.slice(32, 64),
    mpk: bytes.slice(64, 96),
  };
}

// ========== Viewing Key Delegation ==========

/**
 * Create a delegated viewing key for auditors/compliance
 */
export function createDelegatedViewKey(
  keys: AegisKeys,
  permissions: ViewPermissions = ViewPermissions.FULL,
  options: { expiresAt?: number; label?: string } = {}
): DelegatedViewKey {
  return {
    viewingPrivKey: new Uint8Array(keys.viewingPrivKey),
    permissions,
    expiresAt: options.expiresAt,
    label: options.label,
  };
}

/**
 * Serialize a delegated viewing key for export (ENCRYPTED)
 */
export async function serializeDelegatedViewKey(
  key: DelegatedViewKey,
  password?: string
): Promise<string> {
  if (!password) {
    throw new Error(
      "Password required for viewing key serialization. " +
      "Unencrypted export is not permitted for security."
    );
  }

  const passwordBytes = new TextEncoder().encode(password);
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);

  const PBKDF2_ITERATIONS = 600_000;
  const encryptionKey = pbkdf2(sha256, passwordBytes, salt, { c: PBKDF2_ITERATIONS, dkLen: 32 });

  const nonce = new Uint8Array(12);
  crypto.getRandomValues(nonce);

  const keyBuffer = encryptionKey.buffer.slice(
    encryptionKey.byteOffset,
    encryptionKey.byteOffset + encryptionKey.byteLength
  ) as ArrayBuffer;
  const nonceBuffer = nonce.buffer.slice(
    nonce.byteOffset,
    nonce.byteOffset + nonce.byteLength
  ) as ArrayBuffer;
  const dataBuffer = key.viewingPrivKey.buffer.slice(
    key.viewingPrivKey.byteOffset,
    key.viewingPrivKey.byteOffset + key.viewingPrivKey.byteLength
  ) as ArrayBuffer;

  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    keyBuffer,
    { name: "AES-GCM" },
    false,
    ["encrypt"]
  );

  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonceBuffer },
    cryptoKey,
    dataBuffer
  );

  const obj = {
    version: 1,
    encrypted: true,
    salt: bytesToHex(salt),
    nonce: bytesToHex(nonce),
    ciphertext: bytesToHex(new Uint8Array(ciphertext)),
    permissions: key.permissions,
    expiresAt: key.expiresAt,
    label: key.label,
  };
  return JSON.stringify(obj);
}

/**
 * Deserialize a delegated viewing key from JSON
 */
export async function deserializeDelegatedViewKey(
  json: string,
  password?: string
): Promise<DelegatedViewKey> {
  let obj;
  try {
    obj = JSON.parse(json);
  } catch {
    throw new Error("Invalid delegated view key format");
  }

  if (!obj.encrypted) {
    const privKeyBytes = hexToBytes(obj.viewingPrivKey);
    return {
      viewingPrivKey: privKeyBytes,
      permissions: obj.permissions,
      expiresAt: obj.expiresAt,
      label: obj.label,
    };
  }

  if (!password) {
    throw new Error("Password required to decrypt viewing key");
  }

  const salt = hexToBytes(obj.salt);
  const nonce = hexToBytes(obj.nonce);
  const ciphertext = hexToBytes(obj.ciphertext);
  const passwordBytes = new TextEncoder().encode(password);

  if (obj.version === 1) {
    const iterations = 150_000;
    const encryptionKey = pbkdf2(sha256, passwordBytes, salt, { c: iterations, dkLen: 32 });

    const keyBuffer = encryptionKey.buffer.slice(
      encryptionKey.byteOffset,
      encryptionKey.byteOffset + encryptionKey.byteLength
    ) as ArrayBuffer;
    const nonceBuffer = nonce.buffer.slice(
      nonce.byteOffset,
      nonce.byteOffset + nonce.byteLength
    ) as ArrayBuffer;
    const ciphertextBuffer = ciphertext.buffer.slice(
      ciphertext.byteOffset,
      ciphertext.byteOffset + ciphertext.byteLength
    ) as ArrayBuffer;

    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      keyBuffer,
      { name: "AES-GCM" },
      false,
      ["decrypt"]
    );

    try {
      const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: nonceBuffer },
        cryptoKey,
        ciphertextBuffer
      );
      return {
        viewingPrivKey: new Uint8Array(plaintext),
        permissions: obj.permissions,
        expiresAt: obj.expiresAt,
        label: obj.label,
      };
    } catch {
      throw new Error("Invalid password or corrupted data");
    }
  }

  throw new Error(
    "Unsupported encryption format (version " + obj.version + "). " +
    "Only version 1 (AES-GCM with Ed25519 keys) is supported."
  );
}

/**
 * Check if a delegated viewing key is valid (not expired)
 */
export function isDelegatedKeyValid(key: DelegatedViewKey): boolean {
  if (!key.expiresAt) return true;
  return Date.now() < key.expiresAt;
}

/**
 * Check if a delegated key has a specific permission
 */
export function hasPermission(
  key: DelegatedViewKey,
  permission: ViewPermissions
): boolean {
  return (key.permissions & permission) === permission;
}

// ========== Key Security ==========

/**
 * Safely compare two keys in constant time
 */
export function constantTimeCompare(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a[i] ^ b[i];
  }
  return result === 0;
}

/**
 * Securely clear sensitive key material from memory
 */
export function clearKey(key: Uint8Array): void {
  crypto.getRandomValues(key);
  key.fill(0);
}

/**
 * Securely clear all sensitive keys from an AegisKeys object
 */
export function clearAegisKeys(keys: AegisKeys): void {
  (keys as { spendingPrivKey: bigint }).spendingPrivKey = 0n;
  (keys as { nullifyingKey: bigint }).nullifyingKey = 0n;
  clearKey(keys.viewingPrivKey);
  clearKey(keys.eddsaSeed);
}

/**
 * Securely clear a delegated viewing key
 */
export function clearDelegatedViewKey(key: DelegatedViewKey): void {
  clearKey(key.viewingPrivKey);
}

/**
 * Derive a view-only key bundle (no spending key)
 * Safe to export/backup separately from spending key
 */
export function extractViewOnlyBundle(keys: AegisKeys): {
  solanaPublicKey: Uint8Array;
  spendingPubKey: Uint8Array;
  viewingPrivKey: Uint8Array;
  viewingPubKey: Uint8Array;
} {
  return {
    solanaPublicKey: keys.solanaPublicKey,
    spendingPubKey: babyJubCompress(keys.spendingPubKey),
    viewingPrivKey: new Uint8Array(keys.viewingPrivKey),
    viewingPubKey: new Uint8Array(keys.viewingPubKey),
  };
}

// ========== Utilities ==========

function concatBytes(...arrays: Uint8Array[]): Uint8Array {
  const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const arr of arrays) {
    result.set(arr, offset);
    offset += arr.length;
  }
  return result;
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function hexToBytes(hex: string): Uint8Array {
  const cleanHex = hex.startsWith("0x") ? hex.slice(2) : hex;
  const bytes = new Uint8Array(cleanHex.length / 2);
  for (let i = 0; i < cleanHex.length; i += 2) {
    bytes[i / 2] = parseInt(cleanHex.substr(i, 2), 16);
  }
  return bytes;
}
